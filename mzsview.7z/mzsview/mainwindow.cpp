#include "mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    m_model(new QStandardItemModel),
    m_rowCount(mzsview::ROWS),
    m_colCount(mzsview::COLUMNS),
    m_datafile("d:\\data.csv")
{
    m_ui.setupUi(this);
    initModel();
    getTags();
    this->setWindowTitle(QString("%1@mzsview").arg(m_datafile));
    connect(m_ui.plotview,&PlotView::cursorValueChanged,this,&MainWindow::getCursorValue);
    connect(m_ui.plotview,&PlotView::tagValueChanged,this,&MainWindow::getTagValue);
    loadView();
}

void MainWindow::initModel()
{
    m_model->setRowCount(mzsview::ROWS);
    m_model->setColumnCount(mzsview::COLUMNS);
    for(int i=0;i<m_colCount;i++){
        m_model->setHeaderData(i,Qt::Horizontal,mzsview::HEADS[i]);
    }
    QModelIndex index;
    QStandardItem *item;
    for(int i=0;i<m_rowCount;i++){
        index=m_model->index(i,mzsview::CURSOR1_COLUMN,QModelIndex());
        item = m_model->itemFromIndex(index);
        item->setFlags(item->flags() ^ Qt::ItemIsEditable);
        index=m_model->index(i,mzsview::CURSOR2_COLUMN,QModelIndex());
        item = m_model->itemFromIndex(index);
        item->setFlags(item->flags() ^ Qt::ItemIsEditable);
        index=m_model->index(i,mzsview::SELECT_COLUMN,QModelIndex());
        m_model->setData(index,mzsview::DEFAULT_SELECT_STATE, Qt::EditRole);
        index=m_model->index(i,mzsview::PHASE_COLUMN,QModelIndex());
        m_model->setData(index,mzsview::DEFAULT_PHASE_STATE, Qt::EditRole);
        index=m_model->index(i,mzsview::COLOR_COLUMN,QModelIndex());
        m_model->setData(index, QVariant(QColor(mzsview::DEFAULT_COLORS[i])), Qt::BackgroundRole);
        index=m_model->index(i,mzsview::MIN_COLUMN,QModelIndex());
        m_model->setData(index, mzsview::DEFAULT_MINS[i], Qt::EditRole);
        index=m_model->index(i,mzsview::MAX_COLUMN,QModelIndex());
        m_model->setData(index,mzsview::DEFAULT_MAXS[i], Qt::EditRole);
    }
    m_ui.tableView->setModel(m_model);    
    ComboboxDelegate* cbdelegate=new ComboboxDelegate;
    m_ui.tableView->setItemDelegateForColumn(mzsview::TAG_COLUMN,cbdelegate);
    CheckDelegate* checkdelegate=new CheckDelegate;
    m_ui.tableView->setItemDelegateForColumn(mzsview::PHASE_COLUMN,checkdelegate);
    m_ui.tableView->setItemDelegateForColumn(mzsview::SELECT_COLUMN,checkdelegate);
    for(int i=0;i<mzsview::ROWS;i++){
        m_ui.tableView->openPersistentEditor(m_model->index(i,mzsview::TAG_COLUMN,QModelIndex()));
        m_ui.tableView->openPersistentEditor(m_model->index(i,mzsview::SELECT_COLUMN,QModelIndex()));
        m_ui.tableView->openPersistentEditor(m_model->index(i,mzsview::PHASE_COLUMN,QModelIndex()));
    }
    ColorDelegate* colordelegate=new ColorDelegate;
    m_ui.tableView->setItemDelegateForColumn(mzsview::COLOR_COLUMN,colordelegate);
}

int MainWindow::loadView(){
    m_ui.plotview->setDatafile(m_datafile);
    m_ui.plotview->loadChart();
    return 0;
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    resize(event->size());
    int height=event->size().height()-20;
    int width=event->size().width();
    m_ui.plotview->setGeometry(QRect(mzsview::PADDING, 0, width-2*mzsview::PADDING
                                     , height-mzsview::TABLE_HEIGHT-mzsview::PADDING));
    m_ui.tableView->setGeometry(QRect(mzsview::PADDING, height-mzsview::TABLE_HEIGHT-mzsview::PADDING
                                      , width-2*mzsview::PADDING, mzsview::TABLE_HEIGHT));
    int table_width=m_ui.tableView->size().width();
    for(int i=0;i<mzsview::COLUMNS;i++){
        m_ui.tableView->setColumnWidth(i,int(table_width*mzsview::COLUMN_WIDTH[i]/100.0));
    }
    int row_height=m_ui.tableView->size().height()/(m_rowCount+1);
    for(int i=0;i<m_rowCount;i++){
        m_ui.tableView->setRowHeight(i,row_height);
    }
    m_ui.tableView->horizontalHeader()->setStretchLastSection(true);
    QWidget::resizeEvent(event);
}

void MainWindow::getCursorValue(int cursorColumn,QList<double> y_list)
{
    double y;
    for(int i=0;i<y_list.size();i++){
        y=y_list.at(i);
        m_model->setData(m_model->index(i,cursorColumn,QModelIndex()),y);
    }
}

int MainWindow::getTags()
{
    QFile datafile(m_datafile);
    if (!datafile.open(QIODevice::ReadOnly | QIODevice::Text)) {
         return -1;
     }
    QTextStream stream(&datafile);
    QString line = (stream.readLine()).trimmed();
    QStringList values;
    if(line.isEmpty()){
        datafile.close();
        return -1;
    }
    values = line.split(mzsview::DATA_DELIMITER, QString::SkipEmptyParts);
    if(values.size()<2){
        datafile.close();
        return -1;
    }
    values.pop_front();
    ComboboxDelegate* cbdelegate=qobject_cast<ComboboxDelegate*>
            (m_ui.tableView->itemDelegateForColumn(mzsview::TAG_COLUMN));
    for(int i=0;i<mzsview::ROWS;i++){
        m_ui.tableView->closePersistentEditor(m_model->index(i,mzsview::TAG_COLUMN,QModelIndex()));
    }
    cbdelegate->setItemlist(values);
    for(int i=0;i<mzsview::ROWS;i++){
        m_ui.tableView->openPersistentEditor(m_model->index(i,mzsview::TAG_COLUMN,QModelIndex()));
    }
    return 0;
}

void MainWindow::getTagValue(int rowIndex,const QString& tag)
{
    if(rowIndex<m_rowCount){
        QModelIndex index=m_model->index(rowIndex,mzsview::TAG_COLUMN,QModelIndex());
        m_model->setData(index,tag,Qt::EditRole);
    }
}






