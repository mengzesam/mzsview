#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "mzsviewglobal.h"
#include "ui_mainwindow.h"
#include "comboboxdelegate.h"
#include "checkdelegate.h"
#include "colordelegate.h"
#include <QMainWindow>
#include <QStandardItemModel>
#include <QLineSeries>
#include <QChart>
#include <QDateTime>
#include <QDateTimeAxis>
#include <QValueAxis>
#include <QDebug>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void initModel();
    int loadView();
    int getTags();

public slots:
    void getCursorValue(int cursorColumn,QList<double> y_list);
    void getTagValue(int rowIndex,const QString& tag);

protected:
    void resizeEvent(QResizeEvent *event);

private:
    Ui::MainWindow m_ui;
    QStandardItemModel* m_model;
    QChart m_chart;
    int m_rowCount;
    int m_colCount;
    QString m_datafile;

private://const static member

};

#endif // MAINWINDOW_H
